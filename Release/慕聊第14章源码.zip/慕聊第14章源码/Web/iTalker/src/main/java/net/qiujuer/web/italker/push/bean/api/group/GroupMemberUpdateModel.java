package net.qiujuer.web.italker.push.bean.api.group;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class GroupMemberUpdateModel {
}
