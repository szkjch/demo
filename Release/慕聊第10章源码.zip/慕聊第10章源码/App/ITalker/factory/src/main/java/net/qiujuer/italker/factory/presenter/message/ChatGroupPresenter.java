package net.qiujuer.italker.factory.presenter.message;

/**
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class ChatGroupPresenter {
}
