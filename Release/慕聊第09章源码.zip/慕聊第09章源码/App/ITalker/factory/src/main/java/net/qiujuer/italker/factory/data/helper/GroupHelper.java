package net.qiujuer.italker.factory.data.helper;

import net.qiujuer.italker.factory.model.db.Group;

/**
 * 对群的一个简单的辅助工具类
 *
 * @author qiujuer Email:qiujuer@live.cn
 * @version 1.0.0
 */
public class GroupHelper {
    public static Group find(String groupId) {
        // TODO 查询群的信息，先本地，后网络
        return null;
    }

    public static Group findFromLocal(String groupId) {
        // TODO 本地找群信息
        return null;
    }
}
